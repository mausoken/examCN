# Bootstrap 2 Moving Box Carousel

A Pen created on CodePen.io. Original URL: [https://codepen.io/redfrost/pen/AjVdjP](https://codepen.io/redfrost/pen/AjVdjP).

RESPONSIVE MOVING BOX CAROUSEL DEMO
